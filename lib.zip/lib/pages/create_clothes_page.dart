import 'package:flutter/material.dart';
import '../models/clothes_model.dart';
import '../services/clothes_service.dart';

class CreateClothesPage extends StatefulWidget {
  const CreateClothesPage({super.key});

  @override
  State<CreateClothesPage> createState() => _CreateClothesPageState();
}

class _CreateClothesPageState extends State<CreateClothesPage> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _priceController = TextEditingController();
  final _categoryController = TextEditingController();
  final _brandController = TextEditingController();
  final _soldController = TextEditingController();
  final _ratingController = TextEditingController();
  final _stockController = TextEditingController();
  final _yearReleasedController = TextEditingController();
  final _materialController = TextEditingController();

  bool _isLoading = false;
  String? _error;

  final Color primaryColor = const Color(0xFF3E350E);
  final Color accentColor = const Color(0xFFDAAD29);
  final Color backgroundColor = const Color(0xFFEAE9E7);
  final Color borderColor = const Color(0xFF794515);
  final Color secondaryColor = const Color(0xFF79792E);
  final Color highlightColor = const Color(0xFFF2DD6C);

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    final clothes = Clothes(
      name: _nameController.text,
      price: int.parse(_priceController.text),
      category: _categoryController.text,
      brand: _brandController.text,
      sold: int.parse(_soldController.text),
      rating: double.parse(_ratingController.text),
      stock: int.parse(_stockController.text),
      yearReleased: int.parse(_yearReleasedController.text),
      material: _materialController.text,
    );

    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      await ClothesService.createClothes(clothes);
      if (context.mounted) Navigator.pop(context, true);
    } catch (e) {
      setState(() {
        _error = e.toString();
      });
    }

    setState(() {
      _isLoading = false;
    });
  }

  Widget _buildTextField(String label, TextEditingController controller, TextInputType type) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextFormField(
        controller: controller,
        keyboardType: type,
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: primaryColor),
          filled: true,
          fillColor: highlightColor.withOpacity(0.1),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: borderColor),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: accentColor, width: 2),
          ),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: Colors.red),
          ),
        ),
        validator: (value) => value == null || value.isEmpty ? 'Wajib diisi' : null,
      ),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _priceController.dispose();
    _categoryController.dispose();
    _brandController.dispose();
    _soldController.dispose();
    _ratingController.dispose();
    _stockController.dispose();
    _yearReleasedController.dispose();
    _materialController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        backgroundColor: primaryColor,
        iconTheme: const IconThemeData(color: Colors.white),
        title: const Text('Tambah Pakaian', style: TextStyle(color: Colors.white)),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              _buildTextField('Nama', _nameController, TextInputType.text),
              _buildTextField('Harga', _priceController, TextInputType.number),
              _buildTextField('Kategori', _categoryController, TextInputType.text),
              _buildTextField('Brand', _brandController, TextInputType.text),
              _buildTextField('Terjual', _soldController, TextInputType.number),
              _buildTextField('Rating (0-5)', _ratingController, TextInputType.number),
              _buildTextField('Stok', _stockController, TextInputType.number),
              _buildTextField('Tahun Rilis', _yearReleasedController, TextInputType.number),
              _buildTextField('Material', _materialController, TextInputType.text),
              const SizedBox(height: 20),
              if (_error != null)
                Text(_error!, style: const TextStyle(color: Colors.red)),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _submit,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: accentColor,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: _isLoading
                      ? const SizedBox(
                    height: 22,
                    width: 22,
                    child: CircularProgressIndicator(
                      color: Colors.white,
                      strokeWidth: 2,
                    ),
                  )
                      : const Text('Simpan', style: TextStyle(fontSize: 16)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
