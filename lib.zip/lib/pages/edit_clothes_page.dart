import 'package:flutter/material.dart';
import 'package:tugas3_praktikum_mobile/models/clothes_model.dart';
import 'package:tugas3_praktikum_mobile/services/clothes_service.dart';

class EditClothesPage extends StatefulWidget {
  final int id;
  const EditClothesPage({super.key, required this.id});

  @override
  State<EditClothesPage> createState() => _EditClothesPageState();
}

class _EditClothesPageState extends State<EditClothesPage> {
  final TextEditingController name = TextEditingController();
  final TextEditingController price = TextEditingController();
  final TextEditingController category = TextEditingController();
  final TextEditingController brand = TextEditingController();
  final TextEditingController sold = TextEditingController();
  final TextEditingController rating = TextEditingController();
  final TextEditingController stock = TextEditingController();
  final TextEditingController year = TextEditingController();
  final TextEditingController material = TextEditingController();

  bool _isDataLoaded = false;

  final Color backgroundColor = const Color(0xFFEAE9E7);
  final Color primaryColor = const Color(0xFFDAAD29);
  final Color textColor = const Color(0xFF3E350E);
  final Color accentColor = const Color(0xFF794515);
  final Color buttonColor = const Color(0xFFF2DD6C);
  final Color inputBorderColor = const Color(0xFF79792E);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        backgroundColor: primaryColor,
        title: const Text("Edit Pakaian"),
        centerTitle: true,
        titleTextStyle: const TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
          color: Colors.white,
        ),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Padding(
        padding: const EdgeInsets.all(25),
        child: FutureBuilder(
          future: ClothesService.getClothesById(widget.id),
          builder: (context, snapshot) {
            if (snapshot.hasError) {
              return Text("Error: ${snapshot.error}");
            } else if (snapshot.hasData) {
              if (!_isDataLoaded) {
                _isDataLoaded = true;
                final Clothes data = snapshot.data!;
                name.text = data.name;
                price.text = data.price.toString();
                category.text = data.category;
                brand.text = data.brand ?? "";
                sold.text = data.sold.toString();
                rating.text = data.rating.toString();
                stock.text = data.stock.toString();
                year.text = data.yearReleased.toString();
                material.text = data.material ?? "";
              }
              return _formEdit();
            } else {
              return const Center(child: CircularProgressIndicator());
            }
          },
        ),
      ),
    );
  }

  Widget _formEdit() {
    return ListView(
      children: [
        _buildInput("Nama", name),
        _buildInput("Harga", price, isNumber: true),
        _buildInput("Kategori", category),
        _buildInput("Brand", brand),
        _buildInput("Jumlah Terjual", sold, isNumber: true),
        _buildInput("Rating", rating, isNumber: true),
        _buildInput("Stok", stock, isNumber: true),
        _buildInput("Tahun Rilis", year, isNumber: true),
        _buildInput("Material", material),
        const SizedBox(height: 24),
        ElevatedButton(
          onPressed: _updateClothes,
          style: ElevatedButton.styleFrom(
            backgroundColor: buttonColor,
            foregroundColor: textColor,
            padding: const EdgeInsets.symmetric(vertical: 14),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          child: const Text(
            "Simpan Perubahan",
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
        ),
      ],
    );
  }

  Widget _buildInput(String label, TextEditingController controller, {bool isNumber = false}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextField(
        controller: controller,
        keyboardType: isNumber ? TextInputType.number : TextInputType.text,
        decoration: InputDecoration(
          isDense: true,
          labelText: label,
          labelStyle: TextStyle(
            color: textColor,
            overflow: TextOverflow.ellipsis,
            fontSize: 14,
          ),
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(color: inputBorderColor, width: 2),
            borderRadius: BorderRadius.circular(10),
          ),
        ),
      ),
    );
  }


  Future<void> _updateClothes() async {
    try {
      final clothes = Clothes(
        id: widget.id,
        name: name.text.trim(),
        price: int.parse(price.text),
        category: category.text.trim(),
        brand: brand.text.trim(),
        sold: int.parse(sold.text),
        rating: double.parse(rating.text),
        stock: int.parse(stock.text),
        yearReleased: int.parse(year.text),
        material: material.text.trim(),
      );

      await ClothesService.updateClothes(widget.id, clothes);

      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            backgroundColor: accentColor,
            content: Text("Berhasil mengupdate ${clothes.name}", style: const TextStyle(color: Colors.white)),
          ),
        );
        Navigator.pop(context, true);
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: Colors.red,
          content: Text("Gagal: $e", style: const TextStyle(color: Colors.white)),
        ),
      );
    }
  }
}
