class Clothes {
  final int? id;
  final String name;
  final int price;
  final String category;
  final String brand;
  final int sold;
  final double rating;
  final int stock;
  final int yearReleased;
  final String material;

  Clothes({
    this.id,
    required this.name,
    required this.price,
    required this.category,
    required this.brand,
    required this.sold,
    required this.rating,
    required this.stock,
    required this.yearReleased,
    required this.material,
  });

  factory Clothes.fromJson(Map<String, dynamic> json) {
    return Clothes(
      id: json['id'] ?? 0,
      name: json['name'] ?? '',
      price: json['price'] ?? 0,
      category: json['category'] ?? '',
      brand: json['brand'] ?? 'Tidak diketahui',
      sold: json['sold'] ?? 0,
      rating: (json['rating'] ?? 0).toDouble(),
      stock: json['stock'] ?? 0,
      yearReleased: json['yearReleased'] ?? 2000,
      material: json['material'] ?? 'Tidak diketahui',
    );
  }


  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'price': price,
      'category': category,
      'brand': brand,
      'sold': sold,
      'rating': rating,
      'stock': stock,
      'yearReleased': yearReleased,
      'material': material,
    };
  }
}